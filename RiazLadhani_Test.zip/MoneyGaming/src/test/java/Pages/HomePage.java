package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	private WebDriver driver;
	
	private By JoinNowLink = By.cssSelector("div[class='login_links'] [class='newUser green']");
	//@FindBy(css="div[class='login_links'] [class='newUser green']")
	//WebElement JoinNowLink;
	
	public HomePage(WebDriver Driver)
	{
		driver = Driver;	
		//PageFactory.initElements(driver, HomePage.class);
	}
	
	public void ClickJoinNowLink()
	{		
		driver.findElement(JoinNowLink).click();
		//JoinNowLink.click();
	}	
}
